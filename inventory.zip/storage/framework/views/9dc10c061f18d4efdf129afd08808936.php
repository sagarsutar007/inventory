<div class="modal" tabindex="-1" id="<?php echo e($id); ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <?php echo e($header); ?>

      </div>
      <div class="modal-body" style="background-color: #f9f9f9;">
        <?php echo e($body); ?>

      </div>
      <div class="modal-footer">
        <?php echo e($footer); ?>

      </div>
    </div>
  </div>
</div>
<?php /**PATH D:\xampp\htdocs\inventory\resources\views/components/modaltabs.blade.php ENDPATH**/ ?>