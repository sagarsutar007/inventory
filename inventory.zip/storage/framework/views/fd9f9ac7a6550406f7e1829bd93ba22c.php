<div class="col-md-12">
    <input type="hidden" id="material-id" value="<?php echo e($material->material_id); ?>">
    <div class="raw-material-item-container">
        <div class="row">
            <div class="col-12 col-md-9">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="description" placeholder="Enter material name" value="<?php echo e($material->description); ?>">
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <input type="number" class="form-control" name="opening_balance" placeholder="Opening Bal." value="<?php echo e($material->opening_balance); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <select class="form-control select2" id="uom" name="uom_id">
                            <option value=""></option>
                            <?php $__currentLoopData = $uoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($material->uom_id == $unit->uom_id): ?>
                                    <option value="<?php echo e($unit->uom_id); ?>" selected><?php echo e($unit->uom_text); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($unit->uom_id); ?>"><?php echo e($unit->uom_text); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <select class="form-control" id="commodity" name="commodity_id">
                            <option value=""></option>
                            <?php $__currentLoopData = $commodities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmdty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($material->commodity_id == $cmdty->commodity_id): ?>
                                    <option value="<?php echo e($cmdty->commodity_id); ?>" selected><?php echo e($cmdty->commodity_name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($cmdty->commodity_id); ?>"><?php echo e($cmdty->commodity_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <select class="form-control" id="category" name="category_id">
                            <option value=""></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($material->category_id == $ctg->category_id): ?>
                                    <option value="<?php echo e($ctg->category_id); ?>" selected><?php echo e($ctg->category_name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($ctg->category_id); ?>"><?php echo e($ctg->category_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group">
                        <div class="custom-file">
                            <input type="file" name="photo" class="custom-file-input" id="material-img" accept="image/*">
                            <label class="custom-file-label" for="material-img">Material Photo</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group">
                        <div class="custom-file">
                            <input type="file" name="pdf" class="custom-file-input" id="material-pdf" accept="application/pdf">
                            <label class="custom-file-label" for="material-pdf">Material PDF</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group">
                        <div class="custom-file">
                            <input type="file" name="doc" class="custom-file-input" id="material-doc" accept=".doc, .docx, application/msword, application/vnd.openxmlformats-officedocument.wordprocessingml.document, .xls, .xlsx, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet">
                            <label class="custom-file-label" for="material-doc">Material Document</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="input-group mb-3">
                <textarea class="form-control" name="additional_notes" placeholder="Additional notes"><?php echo e($material->additional_notes); ?></textarea>
            </div>
        </div>
        <h5>Bill of Material</h5>
        <div class="raw-materials-container">
            <?php if(!empty($bomRecords)): ?>
                <?php $__currentLoopData = $bomRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bomRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="raw-with-quantity">
                        <div class="row">
                            <div class="col-md-8">
                                <select class="form-control raw-materials" name="raw[]" style="width:100%;">
                                    <option value=""></option>  
                                    <option value="<?php echo e($bomRecord->material_id); ?>" selected><?php echo e($bomRecord->material->description ."-". $bomRecord->material->part_code); ?></option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" name="quantity[]" placeholder="Quantity" value="<?php echo e($bomRecord->quantity); ?>">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="fas fa-times remove-raw-quantity-item"></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>                            
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
                <p class="text-secondary">No Bill of Materials found! To create a new one press <code>Add BOM Item</code> button.</p>
            <?php endif; ?>
        </div>
        
        <h6>Uploaded Documents</h6>
        <p class="text-danger">Note: Deleting this picture will instatntly delete the document from your account. Please make sure you want to do that before proceeding.</p>
        <div class="row">
            <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($attachment->type === 'image'): ?>
                    <div class="col-md-4">
                        <div class="card card-primary card-outline">
                            <img class="img-fluid" src="<?php echo e(asset('assets/uploads/materials/' . $attachment->path)); ?>" alt="Attachment Image">
                            <div class="card-body">
                                <h5 class="card-title">Material Image</h5><br>
                                <div class="btn-group w-100">
                                    <a href="<?php echo e(asset('assets/uploads/materials/' . $attachment->path)); ?>" target="_blank" class="btn btn-primary btn-block mt-3">View</a>
                                    <button type="button" data-attid="<?php echo e($attachment->mat_doc_id); ?>" class="btn btn-danger btn-block mt-3 btn-destroy-attachment">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($attachment->type === 'pdf'): ?>
                    <div class="col-md-4">
                        <div class="card card-primary card-outline">
                            <img class="img-fluid" src="<?php echo e(asset('assets/img/pdf.png')); ?>" alt="Attachment Image">
                            <div class="card-body">
                                <h5 class="card-title">Material PDF</h5><br>
                                <div class="btn-group w-100">
                                    <a href="<?php echo e(asset('assets/uploads/pdf/' . $attachment->path)); ?>" target="_blank" class="btn btn-primary btn-block mt-3">View</a>
                                    <button type="button" data-attid="<?php echo e($attachment->mat_doc_id); ?>" class="btn btn-danger btn-block mt-3 btn-destroy-attachment">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($attachment->type === 'doc'): ?>
                    <div class="col-md-4">
                        <div class="card card-primary card-outline">
                            <img class="img-fluid" src="<?php echo e(asset('assets/img/documents.jpg')); ?>" alt="Attachment Image">
                            <div class="card-body">
                                <h5 class="card-title">Material Document</h5><br>
                                <div class="btn-group w-100">
                                    <a href="<?php echo e(asset('assets/uploads/doc/' . $attachment->path)); ?>" target="_blank" class="btn btn-primary btn-block mt-3">View</a>
                                    <button type="button" data-attid="<?php echo e($attachment->mat_doc_id); ?>" class="btn btn-danger btn-block mt-3 btn-destroy-attachment">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\inventory\resources\views/edit-semi-material.blade.php ENDPATH**/ ?>