<div class="col-md-12">
    <input type="hidden" id="bom-id" value="<?php echo e($bom->bom_id); ?>">
    <div class="raw-material-item-container">
        <h6>Bill of Material</h6>
        <div class="raw-materials-container">
            <?php $__currentLoopData = $bom->bomRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bomRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="raw-with-quantity">
                    <div class="row">
                        <div class="col-md-8">
                            <select class="form-control raw-materials" name="raw[]" style="width:100%;">
                                <option value=""></option>  
                                <option value="<?php echo e($bomRecord->material_id); ?>" selected><?php echo e($bomRecord->material->description ."-". $bomRecord->material->part_code); ?></option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <div class="input-group mb-3">
                                <input type="number" class="form-control" name="quantity[]" placeholder="Quantity" value="<?php echo e($bomRecord->quantity); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="fas fa-times remove-raw-quantity-item"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>                            
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\inventory\resources\views/bom/edit-bom-material.blade.php ENDPATH**/ ?>