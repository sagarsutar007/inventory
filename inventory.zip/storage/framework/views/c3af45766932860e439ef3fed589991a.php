<div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="home-tab">
    <div class="row">
        <div class="col-md-5">
            <h6>Material Information</h6>
            <div class="card card-primary card-outline">
                <div class="card-body box-profile">
                    <div class="text-center">
                        <?php $imageFound = false; ?>
                        <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($attachment->type === 'image'): ?>
                                <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('assets/uploads/materials/' . $attachment->path)); ?>" alt="Attachment Image">
                                <?php $imageFound = true; break; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$imageFound): ?>
                            <!-- Default image if no image is found -->
                            <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('assets/default-image.jpg')); ?>" alt="Default Image">
                        <?php endif; ?>
                    </div>
                    <h3 class="profile-username text-center"><?php echo e($material->description); ?></h3>
                    <p class="text-muted text-center"><?php echo e($material->part_code); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <h6>More Information</h6>
            <div class="card card-primary card-outline">
                <div class="card-body box-profile">
                    <p class="text-muted mb-0"><strong class="text-dark">Make</strong> : <?php echo e($material->make); ?></p>
                    <hr class="my-2">
                    <p class="text-muted mb-0"><strong class="text-dark">MPN</strong> : <?php echo e($material->mpn); ?></p>
                    <hr class="my-2">
                    <p class="text-muted mb-0"><strong class="text-dark">Commodity</strong> : <?php echo e($commodity->commodity_name); ?></p>
                    <hr class="my-2">
                    <p class="text-muted mb-0"><strong class="text-dark">Category</strong> : <?php echo e($category->category_name); ?></p>
                    <hr class="my-2">
                    <p class="text-muted mb-0"><strong class="text-dark">Measurement Unit</strong> : <?php echo e($uom->uom_text); ?></p>
                    <hr class="my-2">
                    <p class="text-muted mb-0"><strong class="text-dark">Additional Notes</strong> : <?php echo e($material->additional_notes); ?></p>
                </div>
            </div>
        </div>
    </div>
    
</div>
<div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="profile-tab">
    <h6>Uploaded Documents</h6>
    <div class="row">
        <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($attachment->type === 'image'): ?>
                <div class="col-md-4">
                    <div class="card card-primary card-outline">
                        <img class="img-fluid" src="<?php echo e(asset('assets/uploads/materials/' . $attachment->path)); ?>" alt="Attachment Image">
                        <div class="card-body">
                            <h5 class="card-title">Material Image</h5><br>
                            <a href="<?php echo e(asset('assets/uploads/materials/' . $attachment->path)); ?>" target="_blank" class="btn btn-primary btn-block mt-3">View</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($attachment->type === 'pdf'): ?>
                <div class="col-md-4">
                    <div class="card card-primary card-outline">
                        <img class="img-fluid" src="<?php echo e(asset('assets/img/pdf.png')); ?>" alt="Attachment Image">
                        <div class="card-body">
                            <h5 class="card-title">Material PDF</h5><br>
                            <a href="<?php echo e(asset('assets/uploads/pdf/' . $attachment->path)); ?>" target="_blank" class="btn btn-primary btn-block mt-3">View</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if($attachment->type === 'doc'): ?>
                <div class="col-md-4">
                    <div class="card card-primary card-outline">
                        <img class="img-fluid" src="<?php echo e(asset('assets/img/documents.jpg')); ?>" alt="Attachment Image">
                        <div class="card-body">
                            <h5 class="card-title">Material Document</h5><br>
                            <a href="<?php echo e(asset('assets/uploads/doc/' . $attachment->path)); ?>" target="_blank" class="btn btn-primary btn-block mt-3">View</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<div class="tab-pane fade" id="vendors" role="tabpanel" aria-labelledby="vendors-tab">
    <h6>Vendors</h6>
    <div class="card">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Sno.</th>
                            <th>Vendor Name</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($purchases)): ?>
                            <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?>.</td>
                                    <td><?php echo e($purchase->vendor->vendor_name); ?></td>
                                    <td><?php echo e($purchase->price); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3">No vendors records found!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\inventory\resources\views/view-raw-material.blade.php ENDPATH**/ ?>