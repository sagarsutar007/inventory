

<?php $__env->startSection('title', 'Warehouse'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card mt-3">
                <div class="card-header">
                    <h3 class="card-title">Warehouse</h3>
                    <div class="card-tools">
                        <div class="btn-group">
                            <button type="button" class="btn btn-light dropdown-toggle dropdown-icon-disabled btn-sm" data-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right" role="menu">
                                <a class="dropdown-item" href="<?php echo e(route('wh.issue')); ?>"><i class="fa fa-minus text-danger"></i> Issue</a>
                                <a class="dropdown-item" href="<?php echo e(route('wh.receive')); ?>"><i class="fa fa-plus text-primary"></i> Receive</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table id="materials" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <!-- <th width="5%">Sno.</th> -->
                                <th width="10%">Part Code</th>
                                <th>Description</th>
                                <th>Unit</th>
                                <th>Opening</th>
                                <th>Receipt</th>
                                <th>Issue</th>
                                <th>Closing</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(function () {
            $('#materials').DataTable({
                "responsive": true,
                "lengthChange": true,
                "autoWidth": true,
                "paging": true,
                "info": true,
                "buttons": [
                    {
                        extend: 'excel',
                        exportOptions: {
                            columns: ':visible:not(.exclude)'
                        }
                    },
                    {
                        extend: 'pdf',
                        exportOptions: {
                            columns: ':visible:not(.exclude)'
                        }
                    },
                    {
                        extend: 'print',
                        exportOptions: {
                            columns: ':visible:not(.exclude)'
                        }
                    },
                    'colvis',
                ],
                "processing": true,
                "serverSide": true,
                "stateSave": true,
                "scrollY": "320px",
                "scrollCollapse": true,
                "ajax": {
                    "url": "<?php echo e(route('wh.getWarehouseRecords')); ?>",
                    "type": "POST",
                    "data": function ( d ) {
                        d._token = '<?php echo e(csrf_token()); ?>';
                    }
                },
                "columns": [
                    // { "data": "sno", "name": "sno"},
                    { "data": "code", "name": "part_code" },
                    { "data": "material_name", "name": "description" },
                    { "data": "unit", "name": "uom_text" },
                    { "data": "opening_balance", "name": "opening_balance" },
                    { "data": "receipt_qty", "name": "receipt_qty" },
                    { "data": "issue_qty", "name": "issue_qty" },
                    { "data": "closing_balance", "name": "closing_balance" },
                    // { "data": "action" },
                ],
                "lengthMenu": [10, 25, 50, 75, 100],
                "searching": true,
                "ordering": true,
                "columnDefs": [
                    {
                        "targets": [4],
                        "orderable": false
                    }
                ],
                "dom": 'lBfrtip',
                "language": {
                    "lengthMenu": "_MENU_"
                },
            });

            // Show Error Messages
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    toastr.error('<?php echo e($error); ?>');
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            // Show Success Message
            <?php if(session('success')): ?>
                toastr.success('<?php echo e(session('success')); ?>');
            <?php endif; ?>

            $('#modalIssue').on('show.bs.modal', function (event) {
                initializeRawMaterialsSelect2($('#issue-material'));
            });

            $('#modalReceived').on('show.bs.modal', function (event) {
                initializeRawMaterialsSelect2($('#receive-material'));
            });

            function initializeRawMaterialsSelect2(selectElement) {
                selectElement.select2({
                    placeholder: 'Raw materials',
                    theme: 'bootstrap4',
                    ajax: {
                        url: '<?php echo e(route("semi.getRawMaterials")); ?>',
                        method: 'POST',
                        dataType: 'json',
                        delay: 250,
                        data: function (params) {
                            return {
                                q: params.term,
                                _token : '<?php echo e(csrf_token()); ?>',
                            };
                        },
                        processResults: function (data) {
                            return {
                                results: $.map(data, function (item) {
                                    return {
                                        id: item.material_id,
                                        text: item.description + "-" + item.part_code
                                    };
                                })
                            };
                        },
                        cache: true
                    }
                });
            }

            $('.btn-issue-material').click(function () {
                var _url = '<?php echo e(route('wh.issue')); ?>';
                var _formData = new FormData($('#issue-material-form')[0]);
                makeRequest(_url, _formData);

                $('#modalIssue').modal('hide');
            });

            $('.btn-receive-material').click(function () {
                var _url = '<?php echo e(route('wh.receive')); ?>';
                var _formData = new FormData($('#recieve-material-form')[0]);
                makeRequest(_url, _formData);
                $('#modalReceived').modal('hide');
            });

            function makeRequest(_url, _formData) {
                $.ajax({
                    url: _url, 
                    type: 'POST',
                    data: _formData,
                    processData: false,
                    contentType: false,
                    success: function (response) {
                        if (response.status) {
                            toastr.success(response.message);
                            window.location.reload();
                        } else {
                            toastr.error(response.message);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error(xhr.responseText);
                        var response = JSON.parse(xhr.responseText);
                        toastr.error(response.message);
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\inventory\resources\views/warehouse/list.blade.php ENDPATH**/ ?>