<div class="col-md-12">
    <input type="hidden" id="material-id" value="<?php echo e($material->material_id); ?>">
    <div class="raw-material-item-container">
        <div class="row">
            <div class="col-12 col-md-9">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="description" placeholder="Enter material name" value="<?php echo e($material->description); ?>">
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <input type="number" class="form-control" name="opening_balance" placeholder="Opening Bal." value="<?php echo e($material->opening_balance); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-9">
                <div class="row">
                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" name="make" placeholder="Make" value="<?php echo e($material->make); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <div class="form-group">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control" name="mpn" placeholder="MPN" value="<?php echo e($material->mpn); ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <input type="number" class="form-control" name="re_order" placeholder="Re-Order" value="<?php echo e($material->re_order); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <select class="form-control select2" id="uom" name="uom_id">
                            <option value=""></option>
                            <?php $__currentLoopData = $uoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($material->uom_id == $unit->uom_id): ?>
                                    <option value="<?php echo e($unit->uom_id); ?>" selected><?php echo e($unit->uom_text); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($unit->uom_id); ?>"><?php echo e($unit->uom_text); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <select class="form-control" id="commodity" name="commodity_id">
                            <option value=""></option>
                            <?php $__currentLoopData = $commodities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmdty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($material->commodity_id == $cmdty->commodity_id): ?>
                                    <option value="<?php echo e($cmdty->commodity_id); ?>" selected><?php echo e($cmdty->commodity_name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($cmdty->commodity_id); ?>"><?php echo e($cmdty->commodity_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group mb-3">
                        <select class="form-control" id="category" name="category_id">
                            <option value=""></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($material->category_id == $ctg->category_id): ?>
                                    <option value="<?php echo e($ctg->category_id); ?>" selected><?php echo e($ctg->category_name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($ctg->category_id); ?>"><?php echo e($ctg->category_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group">
                        <div class="custom-file">
                            <input type="file" name="photo" class="custom-file-input" id="material-img" accept="image/*">
                            <label class="custom-file-label" for="material-img">Material Photo</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group">
                        <div class="custom-file">
                            <input type="file" name="pdf" class="custom-file-input" id="material-pdf" accept="application/pdf">
                            <label class="custom-file-label" for="material-pdf">Material PDF</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <div class="input-group">
                        <div class="custom-file">
                            <input type="file" name="doc" class="custom-file-input" id="material-doc">
                            <label class="custom-file-label" for="material-doc">Material Document</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-group">
            <div class="input-group mb-3">
                <textarea class="form-control" name="additional_notes" placeholder="Additional notes"><?php echo e($material->additional_notes); ?></textarea>
            </div>
        </div>
        <h6>Vendors</h6>
        <div class="vendor-price-container">
            <?php if(count($purchases)): ?>
                <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="vendor-with-price">
                        <div class="row">
                            <div class="col-md-8">
                                <input type="text" class="form-control sug-vendor" name="vendor[]" placeholder="Vendor name" value="<?php echo e($purchase->vendor->vendor_name); ?>">
                            </div>
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" name="price[]" placeholder="Price" value="<?php echo e($purchase->price); ?>">
                                    <div class="input-group-append">
                                        <span class="input-group-text"><i class="fas fa-times remove-vendor-price-item"></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>                            
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="vendor-with-price">
                    <div class="row">
                        <div class="col-md-8">
                            <input type="text" class="form-control sug-vendor" name="vendor[]" placeholder="Vendor name" value="">
                        </div>
                        <div class="col-md-4">
                            <div class="input-group mb-3">
                                <input type="number" class="form-control" name="price[]" placeholder="Price" value="">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="fas fa-times remove-vendor-price-item"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>                            
                </div>
                <div class="vendor-with-price">
                    <div class="row">
                        <div class="col-md-8">
                            <input type="text" class="form-control sug-vendor" name="vendor[]" placeholder="Vendor name" value="">
                        </div>
                        <div class="col-md-4">
                            <div class="input-group mb-3">
                                <input type="number" class="form-control" name="price[]" placeholder="Price" value="">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="fas fa-times remove-vendor-price-item"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>                            
                </div>
                <div class="vendor-with-price">
                    <div class="row">
                        <div class="col-md-8">
                            <input type="text" class="form-control sug-vendor" name="vendor[]" placeholder="Vendor name" value="">
                        </div>
                        <div class="col-md-4">
                            <div class="input-group mb-3">
                                <input type="number" class="form-control" name="price[]" placeholder="Price" value="">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="fas fa-times remove-vendor-price-item"></i></span>
                                </div>
                            </div>
                        </div>
                    </div>                            
                </div>
            <?php endif; ?>
        </div>

        <h6>Uploaded Documents</h6>
        <p class="text-danger">Note: Deleting this picture will instatntly delete the document from your account. Please make sure you want to do that before proceeding.</p>
        <div class="row">
            <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($attachment->type === 'image'): ?>
                    <div class="col-md-4">
                        <div class="card card-primary card-outline">
                            <img class="img-fluid" src="<?php echo e(asset('assets/uploads/materials/' . $attachment->path)); ?>" alt="Attachment Image">
                            <div class="card-body">
                                <h5 class="card-title">Material Image</h5><br>
                                <div class="btn-group w-100">
                                    <a href="<?php echo e(asset('assets/uploads/materials/' . $attachment->path)); ?>" target="_blank" class="btn btn-primary btn-block mt-3">View</a>
                                    <button type="button" data-attid="<?php echo e($attachment->mat_doc_id); ?>" class="btn btn-danger btn-block mt-3 btn-destroy-attachment">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($attachment->type === 'pdf'): ?>
                    <div class="col-md-4">
                        <div class="card card-primary card-outline">
                            <img class="img-fluid" src="<?php echo e(asset('assets/img/pdf.png')); ?>" alt="Attachment Image">
                            <div class="card-body">
                                <h5 class="card-title">Material PDF</h5><br>
                                <div class="btn-group w-100">
                                    <a href="<?php echo e(asset('assets/uploads/pdf/' . $attachment->path)); ?>" target="_blank" class="btn btn-primary btn-block mt-3">View</a>
                                    <button type="button" data-attid="<?php echo e($attachment->mat_doc_id); ?>" class="btn btn-danger btn-block mt-3 btn-destroy-attachment">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($attachment->type === 'doc'): ?>
                    <div class="col-md-4">
                        <div class="card card-primary card-outline">
                            <img class="img-fluid" src="<?php echo e(asset('assets/img/documents.jpg')); ?>" alt="Attachment Image">
                            <div class="card-body">
                                <h5 class="card-title">Material Document</h5><br>
                                <div class="btn-group w-100">
                                    <a href="<?php echo e(asset('assets/uploads/doc/' . $attachment->path)); ?>" target="_blank" class="btn btn-primary btn-block mt-3">View</a>
                                    <button type="button" data-attid="<?php echo e($attachment->mat_doc_id); ?>" class="btn btn-danger btn-block mt-3 btn-destroy-attachment">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\inventory\resources\views/edit-raw-material.blade.php ENDPATH**/ ?>